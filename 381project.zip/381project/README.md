"# inventory_sys" 
First ,when the user visit the website will be direct to the login page.
There have two user , one of the account  name: 'test', password: '123' .Another one  name: 'student', password: '123' .
After login , you can use the button call "Create the new inventory" to create a inventory.
After create the inventory , you can see the list of the inventory on the home page .
And the top of the table , there have a search bar to serarch the record .
If you want to delete or edit the record ,click the name of the inventory.Then will direct to the display page , and the have a button of delete and edit .

 

