const fs = require('fs');
const MongoClient = require('mongodb').MongoClient;
const ObjectId = require('mongodb').ObjectID;
const assert = require('assert');
const express = require('express');
const bodyParser = require('body-parser');
const session = require('cookie-session');
const formidable = require('formidable');
const app = express();

//db var
const dbUrl = 'mongodb+srv://chanwaihei:123@cluster0.ajhkzgi.mongodb.net/?retryWrites=true&w=majority';
const dbName = 'test';
const collectionName = 'inventory';
//

//var
const port = 8099;
const SECRETKEY = '381 project';
const users = new Array(
    { name: 'test', password: '123' },
    { name: 'student', password: '123' }
);


app.use(session({
    name: 'loginSession',
    keys: [SECRETKEY]
}));

app.set('view engine', 'ejs'); //set ejs as view
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(function (req, res, next) { // middleware #1
    console.log(`[*] ${req.method} ${req.path} was requested at ${Date.now()}`);
    next();
})

//middleware
//RESTful api
app.get('/api/inventory/:searchType/:value', (req, res) => {
    res.status(200)
    let searchType = req.params.searchType
    switch (searchType) {
        case "name":
            dbQueryOption = { name: req.params.value }
            dbFind(dbQueryOption, (docsInArray) => {
                res.type('json');
                res.json(docsInArray);
            })
            break;
        case "type":
            dbQueryOption = { type: req.params.value }
            dbFind(dbQueryOption, (docsInArray) => {
                res.type('json');
                res.json(docsInArray);
            })
            break;
        default:
            res.render("error404", { path: req.path })
    }
})

//login
app.use(function (req, res, next) {
    if (!req.session.authenticated && req.path != "/login") {    // user not logged in!
        console.log("[*] redirect to /login from middleware");
        return res.redirect('/login');
    }
    else {
        next();
    }
});

app.get('/', (req, res) => {
    res.status(200)
    dbFind("", (docsInArray) => {
        res.render('home', { username: req.session.username, inv_docs: docsInArray, inv_num: docsInArray.length });
    })
});

app.get('/login', (req, res) => {
    if (!req.session.authenticated) {    // user not logged in!
        res.render('login');
    } else {
        res.redirect('/')
    }
});

app.post('/login', (req, res) => {
    users.forEach((user) => {
        if (user.name == req.body.name && user.password == req.body.password) {
            // correct user name + password
            // store the following name/value pairs in cookie session
            req.session.authenticated = true;        // 'authenticated': true
            req.session.username = req.body.name;	 // 'username': req.body.name
            console.log(`[!] Login successful ${Date.now()}`)
        }
    });
    res.redirect('/');
});

//logout mi logout lo
app.get('/logout', (req, res) => {
    req.session = null;   // clear cookie-session
    res.redirect('/');
});

//Create new inventory documents
app.get('/create', (req, res) => {
    res.status(200)
    res.set('Content-Type', 'text/html');
    res.render('create');
});

app.post('/create', (req, res) => {
    res.status(200)
    const form = new formidable.IncomingForm();
    form.parse(req, (err, fields, files) => {
        fileInput = files.photo
        if (fields.name.length > 0) {
            fs.readFile(fileInput.path, (err, data) => {
                assert.equal(err, null);
                var insertJson = {
                    name: fields.name,
                    type: fields.type,
                    quantity: fields.quantity,
                    inventory_address: [
                        {
                            street: fields.street,
                            building: fields.building,
                            country: fields.country,
                            zipcode: fields.zipcode,
                            coord: [fields.latitude, fields.longitude]
                        }
                    ],
                    manager: req.session.username,
                    photo: new Buffer.from(data).toString('base64'),
                    photo_mimetype: fields.type,
                }
                dbInsert(insertJson)
                res.status(200).send('<html><head><title>Create successful</title></head><body><h1> Create inventory successful</h1> <a href="/">Back to home</a></body></html>');
            })
        } else {
            res.render('errorPage', { info_text: "There is no name in inventory info", referer: "/create" })
        }
    })
})

//Display inventory documents
app.get('/details', (req, res) => {
    res.status(200)
    res.set('Content-Type', 'text/html');
    try {
        var dbQueryOption = { "_id": new ObjectId(req.query._id) }
        dbFind(dbQueryOption, (target) => {
            var inv_id = req.query._id
            var name = target[0].name;
            var type = target[0].type;
            var quantity = target[0].quantity;
            var street = target[0].inventory_address[0].street;
            var building = target[0].inventory_address[0].building;
            var country = target[0].inventory_address[0].country;
            var zipcode = target[0].inventory_address[0].zipcode;
            var lat = target[0].inventory_address[0].coord[0];
            var lon = target[0].inventory_address[0].coord[1];
            var coord = target[0].inventory_address[0].coord;
            var manager = target[0].manager;
            var image = target[0].photo
            var image_mimetype = target[0].photo_mimetype
            res.render('display', {
                image: image,
                name: name,
                type: type,
                quantity: quantity,
                street: street,
                building: building,
                country: country,
                zipcode: zipcode,
                coord: coord,
                lat: lat,
                lon: lon,
                manager: manager,
                image_mimetype: image_mimetype,
                inv_id: inv_id
            });
        })
    } catch (e) {
        console.error("[?] db error /create")
        console.error(e)
        res.status(500)
        res.render('errorPage', { info_text: 'Database Error!  please try again', referer: '/' })
    }

});

//map
app.get('/map', (req, res) => {
    res.render("map", {
        lat: req.query.lat,
        lon: req.query.lon,
        zoom: req.query.zoom ? req.query.zoom : 15
    });
    res.end();
});

//Edit inventory documents
app.get('/edit', (req, res) => {
    res.status(200)
    res.set('Content-Type', 'text/html');
    try {
        var dbQueryOption = { "_id": new ObjectId(req.query._id) }
    } catch (e) {
        console.error("[?] db error /update")
        console.error(e)
        res.status(500)
        res.render('errorPage', { info_text: 'Database Error!  please try again', referer: '/' })
    }

    dbFind(dbQueryOption, (target) => {
        var inv_id = req.query._id
        var image = target[0].photo
        var image_mimetype = target[0].photo_mimetype
        var name = target[0].name;
        var type = target[0].type;
        var quantity = target[0].quantity;
        var street = target[0].inventory_address[0].street;
        var building = target[0].inventory_address[0].building;
        var country = target[0].inventory_address[0].country;
        var zipcode = target[0].inventory_address[0].zipcode;
        var lat = target[0].inventory_address[0].coord[0];
        var lon = target[0].inventory_address[0].coord[1];
        var manager = target[0].manager;
        if (req.session.username == manager) {
            res.render('edit', {
                image: image,
                name: name,
                type: type,
                quantity: quantity,
                street: street,
                building: building,
                country: country,
                zipcode: zipcode,
                lat: lat,
                lon: lon,
                manager: manager,
                referer: req.headers.referer,
                image_mimetype: image_mimetype,
                inv_id: inv_id
            });
        } else {
            res.status(403)
            res.render("errorPage", {
                info_text: "Invalid owner - Only the owner can update the page!",
                referer: req.headers.referer
            })
        }
    })
})

//Update inventory documents after Edit
app.post('/update', (req, res) => {
    res.status(200)
    const form = new formidable.IncomingForm();
    form.parse(req, (err, fields, files) => {
        if (fields.name.length > 0) {
            fs.readFile(files.photo.path, (err, data) => {
                assert.equal(err, null)
                if (files.photo.size > 0) {
                    var updateJson = {
                        name: fields.name,
                        type: fields.type,
                        quantity: fields.quantity,
                        inventory_address: [
                            {
                                street: fields.street,
                                building: fields.building,
                                country: fields.country,
                                zipcode: fields.zipcode,
                                coord: [fields.latitude, fields.longitude]
                            }
                        ],
                        photo: new Buffer.from(data).toString('base64'),
                        photo_mimetype: files.photo.type,
                    }
                } else {
                    var updateJson = {
                        name: fields.name,
                        type: fields.type,
                        quantity: fields.quantity,
                        inventory_address: [
                            {
                                street: fields.street,
                                building: fields.building,
                                country: fields.country,
                                zipcode: fields.zipcode,
                                coord: [fields.latitude, fields.longitude]
                            }
                        ]
                    }
                }
                var dbQueryOption = { "_id": new ObjectId(fields._id) }
                try {
                    dbUpdate(dbQueryOption, updateJson)
                    res.status(200).send('<html><head><title>update successful</title></head><body><h1> Inventory document successful Updated</h1> <a href="/">Back to home</a></body></html>');
                } catch (e) {
                    console.error(e)
                    console.error("[?] db error /update")
                    res.status(500)
                    res.render('errorPage', { info_text: 'Database Error!  please try again', referer: '/' })
                }


            })
        } else {
            res.status(200)
            res.render("errorPage", {
                info_text: "There is no name in inventory info",
                referer: req.headers.referer
            })
        }
    })
});

//delete
app.get('/delete', (req, res) => {
    res.status(200)
    try {
        var deleteQuery = { "_id": new ObjectId(req.query._id) }
        dbFind(deleteQuery, (target) => {
            if (req.session.username == target[0].manager) {
                dbDelete(deleteQuery)
                res.status(200).send('<html><head><title>Create successful</title></head><body><h1> Inventory document successfully deleted.</h1> <a href="/">Back to home</a></body></html>');
            } else {
                res.status(403)
                res.render('errorPage', {
                    info_text: "Access denied - You don't have the access right!",
                    referer: req.headers.referer
                })
            }
        })
    } catch (e) {
        console.error("[?] db error /delete")
        console.error(e)
        res.status(500)
        res.render('errorPage', { info_text: 'Database Error!  please try again', referer: '/' })
    }
})

//404
app.use(function (req, res) {
    res.status(404);
    res.render("errorPage", {
        info_text: `404Error not found ${req.path}`,
        referer: "/"
    })
});

//----------------------------db function----------------------------
//db find function
const dbFind = (dbQueryOption, callback) => {
    const client = new MongoClient(dbUrl, { useNewUrlParser: true });
    client.connect((err) => {
        assert.equal(null, err);
        const db = client.db(dbName);
        console.log('[*] Connected successfully to DB --find');
        var files = db.collection(collectionName).find(dbQueryOption);
        files.toArray((err, docsInArray) => {
            assert.equal(err, null);
            callback(docsInArray)
        });
        client.close();
    })
}

//db insert function
const dbInsert = (insertJson, callback) => {
    const client = new MongoClient(dbUrl, { useNewUrlParser: true });
    client.connect((err) => {
        assert.equal(null, err);
        const db = client.db(dbName);
        db.collection(collectionName).insert(insertJson);
        console.log('[*] Connected successfully to DB --insert');
        client.close();
    })
}

//db update function
const dbUpdate = (dbQueryOption, updateJson, callback) => {
    const client = new MongoClient(dbUrl, { useNewUrlParser: true });
    client.connect((err) => {
        assert.equal(null, err);
        const db = client.db(dbName);
        db.collection(collectionName).update(dbQueryOption, { $set: updateJson });
        console.log('[*] Connected successfully to DB --update');
        client.close();
    })
}

//db delete function
const dbDelete = (deleteJson, callback) => {
    const client = new MongoClient(dbUrl, { useNewUrlParser: true });
    client.connect((err) => {
        assert.equal(null, err);
        const db = client.db(dbName);
        db.collection(collectionName).remove(deleteJson);
        console.log('[*] Connected successfully to DB --remove');
        client.close();
    })
}

app.listen(process.env.PORT || port);
